﻿The azi2pcore_<version>.jar is built directly from a subset of the I2P source - see https://geti2p.net/

Very minor changes have been made to enable I2P to run in the same JVM as BiglyBT